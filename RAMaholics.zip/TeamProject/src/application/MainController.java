package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class MainController implements Initializable {

	ArrayList<Employee> employ = new ArrayList<Employee>();
	Model mod = new Model();

	@FXML
	private PasswordField passField;

	@FXML
	private Button loginButton;

	@FXML
	private Pane pane;

	@FXML
	private Button clockInorOut;


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			mod.ReadEmployeeFile(employ);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		loginButton.setOnAction(e -> {
			try {
				Login(e);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
	}

	@FXML
	void ClockInOut(ActionEvent event) throws IOException{
		pane = FXMLLoader.load(getClass().getResource("ClockInOrOut.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}


	@FXML
	void Login(ActionEvent event) throws IOException{
		Alert alert = new Alert(AlertType.NONE);
		int pass = Integer.parseInt(passField.getText());
		System.out.println(pass);
		Boolean isValid = mod.CheckEmployeeID(employ, pass);


		if(isValid == true){
			TrackEmployeeLogins(passField.getText());
			pane = FXMLLoader.load(getClass().getResource("Selection.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();

		}else {
			alert.setAlertType(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Error!");
			alert.setContentText("Passcode does not exist");
			alert.show();
		}


	}

	public void TrackEmployeeLogins(String employID) throws IOException{
		File fp = new File("employeeloginsession.txt");
		FileWriter write = new FileWriter(fp, true);
		SimpleDateFormat dtf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date currentDate = Calendar.getInstance().getTime();
		String currentDateTime = dtf.format(currentDate);
		String loginID = employID + " " + currentDateTime + "\n";
		write.write(loginID);
		write.close();
	}

}
