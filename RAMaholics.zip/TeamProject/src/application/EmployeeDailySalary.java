package application;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class EmployeeDailySalary {

	int employeeID;
	String date;
	double salary;
	String clockInTime="", clockOutTime="";

	public EmployeeDailySalary(int ID, String date, double salary){
		this.employeeID = ID;
		this.date = date;
		this.salary = salary;
	}

	public EmployeeDailySalary(){
		this(0,"",0);
	}

	public void SetEmployeeID(int ID){
		this.employeeID = ID;
	}

	public void SetDate(String date){
		this.date = date;
	}

	public void SetSalary(double salary){
		this.salary = salary;
	}

	public int GetEmployeeID(){
		return this.employeeID;
	}

	public String GetDate(){
		return this.date;
	}

	public double GetSalary(){
		return this.salary;
	}

	public void SetClockInTime(String clockIn){
		this.clockInTime = clockIn;
	}

	public void SetClockOutTime(String clockOut){
		this.clockOutTime = clockOut;
	}

	public String GetClockIn(){
		return this.clockInTime;
	}

	public String GetClockOut(){
		return this.clockOutTime;
	}
}
