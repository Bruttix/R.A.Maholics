package application;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class SalesController implements Initializable {



	Model mod = new Model();
	int tableCount=0;
	String orderType;
	Alert alert = new Alert(AlertType.NONE);

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		SetVisibility(false,false,false,false,false,false,false,false,false,false);
		list.getItems().clear();
		billTotal.setText("0");

		appetizerButton.setOnAction(e -> HandleAppetizerButton(e));
		kidButton.setOnAction(e -> HandleKidButton(e));
		seafoodButton.setOnAction(e -> HandleSeafoodButton(e));
		beefButton.setOnAction(e -> HandleBeefButton(e));
		chickenButton.setOnAction(e -> HandleChickenButton(e));
		sidesButton.setOnAction(e -> HandleSidesButton(e));
		hotdogButton.setOnAction(e -> HandleHotdogButton(e));
		pizzaButton.setOnAction(e -> HandlePizzaButton(e));
		beveragesButton.setOnAction(e -> HandleBeveragesButton(e));
		noodlesButton.setOnAction(e -> HandleNoodlesButton(e));
		dineInButton.setOnAction(e -> HandleDineIn(e));
		togoButton.setOnAction(e -> HandleToGo(e));
		saveButton.setOnAction(e -> HandleSaveButton(e));
		cancelButton.setOnAction(e -> HandleCancelButton(e));
		homeButton.setOnAction(e -> {
			try {
				HandleHomeButton(e);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});

	}


	@FXML
	void HandleHomeButton(ActionEvent event) throws IOException{
		mod.ClearEmployeeLoginSession();
		Pane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	@FXML
	void HandleSaveButton(ActionEvent event){

		if(!dineInButton.isSelected() && !togoButton.isSelected()){
			alert.setAlertType(AlertType.ERROR);
			alert.setTitle("Error");
			alert.setContentText("Must choose dine in or togo");
			alert.show();
		}else if(dineInButton.isSelected()){
			orderType = "dinein";
		}else {
			orderType = "togo";
		}
		String date = " ", employeeID= " ";
		String amount = billTotal.getText();
		try{
			File fp = new File("employeelogins.txt");
			Scanner scan = new Scanner(fp);
			String values[] = scan.nextLine().split(" ", 2);
			employeeID = values[0];
			date = values[1];

			File order = new File("order.txt");
			FileWriter write = new FileWriter(order, true);
			String orderLine = employeeID + " " + amount + " " + orderType + " " + date + "\n";
			write.write(orderLine);
			write.close();
			scan.close();

			//return to the main screen
			mod.ClearEmployeeLoginSession();
			Pane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();


		}catch(IOException e){
			e.printStackTrace();
		}
	}

	@FXML
	void HandleCancelButton(ActionEvent event){
		list.getItems().clear();
		dineInButton.setSelected(false);
		togoButton.setSelected(false);
		list.getItems().clear();
		dineInButton.setSelected(false);
		togoButton.setSelected(false);
		billTotal.clear();

	}

	@FXML
	void HandleToGo(ActionEvent event){
		tables.setDisable(true);
		dineInButton.setSelected(false);
		orderDetails.setText("To Go");

	}

	@FXML
	void HandleDineIn(ActionEvent event){
		tables.setDisable(false);
		togoButton.setSelected(false);
		orderDetails.setText("Dine In");
		if(tableCount == 0){
			tables.getItems().add("A1");
			tables.getItems().add("A2");
			tables.getItems().add("A3");
			tables.getItems().add("A4");
			tables.getItems().add("A5");
			tables.getItems().add("A6");
			tableCount = 1;
		}

	}
	//appetizer
	@FXML
	void HandleAppetizerButton(ActionEvent event){
		SetVisibility(true,false,false,false,false,false,false,false,false,false);
		eggRollButton.setOnAction(e -> HandleEggRollButton(e));
		fishCakeButton.setOnAction(e -> HandleFishCakeButton(e));
		ceasarSaladButton.setOnAction(e -> HandleCeasarSaladButton(e));
		garlicBreadButton.setOnAction(e -> HandleGarlicBreadButton(e));
	}

	@FXML
	void HandleKidButton(ActionEvent event){
		SetVisibility(false,false,false,false,false,false,false,true,false,false);
		cheeseBurgerButton.setOnAction(e -> HandleCheeseBurgerButton(e));
		chickenFingerButton.setOnAction(e -> HandleChickenFingerButton(e));
		chickenNuggetsButton.setOnAction(e -> HandleChickenNuggetButton(e));
		friedChickenButton.setOnAction(e -> HandleFriedChickenButton(e));
	}

	//beef
	@FXML
	void HandleBeefButton(ActionEvent event){
		SetVisibility(false,false,false,false,false,false,true,false,false,false);
		nyStripButton.setOnAction(e -> HandleNewYorkStripButton(e));
		sirloinButton.setOnAction(e -> HandleSirloinButton(e));
		tBoneButton.setOnAction(e -> HandleTBoneButton(e));
		ribEyeButton.setOnAction(e -> HandleRibEyeButton(e));
	}

	//noodle
	@FXML
	void HandleNoodlesButton(ActionEvent event){
		SetVisibility(false,false,false,false,true,false,false,false,false,false);
		eggNoodleButton.setOnAction(e -> HandleEggNoodleButton(e));
		riceNoodleButton.setOnAction(e -> HandleRiceNoodleButton(e));
		pastaButton.setOnAction(e -> HandlePastaButton(e));
		lomeinButton.setOnAction(e -> HandleLomeinButton(e));
	}

	//seafood
	@FXML
	void HandleSeafoodButton(ActionEvent event){
		SetVisibility(false,false,true,false,false,false,false,false,false,false);
		friedCalamariButton.setOnAction(e -> HandleFriedCalamariButton(e));
		deepFriedCatfishButton.setOnAction(e -> HandleCatFishButton(e));
		grilledShrimpButton.setOnAction(e -> HandleGrilledShrimpButton(e));
		spicySquidButton.setOnAction(e -> HandleSpicySquidButton(e));
	}

	@FXML
	void HandleHotdogButton(ActionEvent event){
		SetVisibility(false,true,false,false,false,false,false,false,false,false);
		texMexButton.setOnAction(e -> HandleTexMexButton(e));
		countyFareButton.setOnAction(e -> HandleCountyFareButton(e));
		macButton.setOnAction(e -> HandleMacButton(e));
		dawgButton.setOnAction(e -> HandleDawgButton(e));
	}

	//pizza
	@FXML
	void HandlePizzaButton(ActionEvent event){
		SetVisibility(false,false,false,false,false,true,false,false,false,false);
		pepperoniButton.setOnAction(e -> HandlePepperoniButton(e));
		cheeseButton.setOnAction(e -> HandleCheesePizzaButton(e));
		allMeatButton.setOnAction(e -> HandleAllMeatButton(e));
		veggieButton.setOnAction(e -> HandleVeggieButton(e));
	}

	//bevearges
	@FXML
	void HandleBeveragesButton(ActionEvent event){
		SetVisibility(true,false,false,false,false,false,false,false,false,true);
		sodaButton.setOnAction(e -> HandleSodaButton(e));
		teaButton.setOnAction(e -> HandleTeaButton(e));
		beerButton.setOnAction(e -> HandleBeerButton(e));
		wineButton.setOnAction(e -> HandleWineButton(e));
	}

	//sides
	@FXML
	void HandleSidesButton(ActionEvent event){
		SetVisibility(false,false,false,false,false,false,false,false,true,false);
		macNCheseButton.setOnAction(e -> HandleMacNCheeseButton(e));
		cheesFriesButton.setOnAction(e -> HandleCheeseFriesButton(e));
		onionRingsButton.setOnAction(e -> HandleOnionRingButton(e));
		riceButton.setOnAction(e -> HandleRiceButton(e));
	}

	//chicken
	@FXML
	void HandleChickenButton(ActionEvent event){
		SetVisibility(false,false,false,true,false,false,false,false,false,false);
		grilledChickenButton.setOnAction(e -> HandleGrilledChickenButton(e));
		lemonChickenButton.setOnAction(e -> HandleLemonChickenButton(e));
		orangeChickenButton.setOnAction(e -> HandleOrangeChickenButton(e));
		sesameChickenButton.setOnAction(e -> HandleSesameChickenButton(e));
	}

	//handle appetizer
		@FXML
		void HandleEggRollButton(ActionEvent event){
			String str = "Egg Roll" + "\t\t\t\t\t" + "$7.75";
			list.getItems().add(str);
			double bill = Double.parseDouble(billTotal.getText()) + 7.75;
			billTotal.setText(Double.toString(bill));
		}

		@FXML
		void HandleFishCakeButton(ActionEvent event){
			String str = "Fish Cake" + "\t\t\t\t\t" + "$8.5";
			list.getItems().add(str);
			double bill = Double.parseDouble(billTotal.getText()) + 8.5;
			billTotal.setText(Double.toString(bill));
		}

		@FXML
		void HandleCeasarSaladButton(ActionEvent event){
			String str = "Ceasar Salad" + "\t\t\t\t\t" + "$8.75";
			list.getItems().add(str);
			double bill = Double.parseDouble(billTotal.getText()) + 8.75;
			billTotal.setText(Double.toString(bill));
		}

		@FXML
		void HandleGarlicBreadButton(ActionEvent event){
			String str = "GarlicBread" + "\t\t\t\t\t" + "$8.5";
			list.getItems().add(str);
			double bill = Double.parseDouble(billTotal.getText()) + 8.5;
			billTotal.setText(Double.toString(bill));
		}//

	//handle hot dog
	@FXML
	void HandleTexMexButton(ActionEvent event){
		String str = "Tex Mex" + "\t\t\t\t\t" + "$9.25";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.25;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleCountyFareButton(ActionEvent event){
		String str = "County Fare" + "\t\t\t\t\t" + "$9.5";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.5;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleMacButton(ActionEvent event){
		String str = "Mac" + "\t\t\t\t\t" + "$9.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleDawgButton(ActionEvent event){
		String str = "Dawg" + "\t\t\t\t\t" + "$9.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.45;
		billTotal.setText(Double.toString(bill));
	}//

	//handle seafood

	@FXML
	void HandleFriedCalamariButton(ActionEvent event){
		String str = "Calamari" + "\t\t\t\t\t" + "$11.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 11.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleCatFishButton(ActionEvent event){
		String str = "Fried Catfish" + "\t\t\t\t\t" + "$13.50";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 13.50;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleGrilledShrimpButton(ActionEvent event){
		String str = "Grilled Shrimp" + "\t\t\t\t\t" + "$12.50";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 12.50;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleSpicySquidButton(ActionEvent event){
		String str = "Spicy Squid" + "\t\t\t\t\t" + "$12.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 12.45;
		billTotal.setText(Double.toString(bill));
	}//

	//handle chicken
	@FXML
	void HandleGrilledChickenButton(ActionEvent event){
		String str = "Grilled Chicken" + "\t\t\t\t\t" + "$9.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleLemonChickenButton(ActionEvent event){
		String str = "Dawg" + "\t\t\t\t\t" + "$8.75";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 8.75;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleOrangeChickenButton(ActionEvent event){
		String str = "Orange Chicken" + "\t\t\t\t\t" + "$8.75";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 8.75;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleSesameChickenButton(ActionEvent event){
		String str = "Sesame Chicken" + "\t\t\t\t\t" + "$8.75";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 8.75;
		billTotal.setText(Double.toString(bill));
	}//

	//handle noodles
	@FXML
	void HandleEggNoodleButton(ActionEvent event){
		String str = "Egg Noodle" + "\t\t\t\t\t" + "$9.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleRiceNoodleButton(ActionEvent event){
		String str = "Rice Noodle" + "\t\t\t\t\t" + "$10.25";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 10.25;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandlePastaButton(ActionEvent event){
		String str = "Pasta" + "\t\t\t\t\t" + "$10.50";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 10.50;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleLomeinButton(ActionEvent event){
		String str = "Dawg" + "\t\t\t\t\t" + "$9.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.45;
		billTotal.setText(Double.toString(bill));
	}//

	//handle pizza
	@FXML
	void HandlePepperoniButton(ActionEvent event){
		String str = "Pepperoni Pizza" + "\t\t\t\t\t" + "$9.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleCheesePizzaButton(ActionEvent event){
		String str = "Cheese Pizza" + "\t\t\t\t\t" + "$9.25";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 9.25;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleAllMeatButton(ActionEvent event){
		String str = "All Meat Pizza" + "\t\t\t\t\t" + "$14.25";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 14.25;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleVeggieButton(ActionEvent event){
		String str = "Veggie Pizza" + "\t\t\t\t\t" + "$10.50";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 10.50;
		billTotal.setText(Double.toString(bill));
	}//

	//handle beef
	@FXML
	void HandleNewYorkStripButton(ActionEvent event){
		String str = "New York Strip" + "\t\t\t\t\t" + "$23.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 23.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleSirloinButton(ActionEvent event){
		String str = "Sirloin" + "\t\t\t\t\t" + "$19.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 19.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleTBoneButton(ActionEvent event){
		String str = "T-Bone" + "\t\t\t\t\t" + "$23.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 23.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleRibEyeButton(ActionEvent event){
		String str = "Rib Eye" + "\t\t\t\t\t" + "$23.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 23.45;
		billTotal.setText(Double.toString(bill));
	}//

	//handle kid
	@FXML
	void HandleCheeseBurgerButton(ActionEvent event){
		String str = "Cheese Burger" + "\t\t\t\t\t" + "$8.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 8.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleChickenFingerButton(ActionEvent event){
		String str = "Chicken Finger" + "\t\t\t\t\t" + "$8.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 8.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleChickenNuggetButton(ActionEvent event){
		String str = "ChickenNugget" + "\t\t\t\t\t" + "$8.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 8.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleFriedChickenButton(ActionEvent event){
		String str = "Fried Chicken" + "\t\t\t\t\t" + "$8.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 8.45;
		billTotal.setText(Double.toString(bill));
	}//

	//handle sides
	@FXML
	void HandleMacNCheeseButton(ActionEvent event){
		String str = "Mac N' Cheese" + "\t\t\t\t\t" + "$7.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 7.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleCheeseFriesButton(ActionEvent event){
		String str = "Cheese Fries" + "\t\t\t\t\t" + "$6.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 6.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleOnionRingButton(ActionEvent event){
		String str = "Onion Ring" + "\t\t\t\t\t" + "$6.45";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 6.45;
		billTotal.setText(Double.toString(bill));
	}

	@FXML
	void HandleRiceButton(ActionEvent event){
		String str = "Rice" + "\t\t\t\t\t" + "$5.25";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 5.25;
		billTotal.setText(Double.toString(bill));
	}//

	//handle beverages
	@FXML
	void HandleSodaButton(ActionEvent event){
		String str = "Soda" + "\t\t\t\t\t" + "$1.75";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 1.75;
		billTotal.setText(Double.toString(bill));
	}//

	@FXML
	void HandleTeaButton(ActionEvent event){
		String str = "Tea" + "\t\t\t\t\t" + "$2.25";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 2.25;
		billTotal.setText(Double.toString(bill));
	}//

	@FXML
	void HandleBeerButton(ActionEvent event){
		String str = "Beer" + "\t\t\t\t\t" + "$3.5";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 3.5;
		billTotal.setText(Double.toString(bill));
	}//

	@FXML
	void HandleWineButton(ActionEvent event){
		String str = "Wine" + "\t\t\t\t\t" + "$5.25";
		list.getItems().add(str);
		double bill = Double.parseDouble(billTotal.getText()) + 5.25;
		billTotal.setText(Double.toString(bill));
	}//



	public void SetVisibility(Boolean app, Boolean hot, Boolean sea, Boolean chick,
							Boolean noo, Boolean piz, Boolean beef, Boolean kid, Boolean sides, Boolean ber){
		appetizerPane.setVisible(app);
		hotdogPane.setVisible(hot);
		seafoodPane.setVisible(sea);
		chickenPane.setVisible(chick);
		noodlesPane.setVisible(noo);
		pizzaPane.setVisible(piz);
		beefPane.setVisible(beef);
		kidPane.setVisible(kid);
		sidesPane.setVisible(sides);
		beveragesPane.setVisible(ber);
	}


	@FXML
	private Button saveButton;

	@FXML
	private Button cancelButton;

	@FXML
	private Button beefButton;

	@FXML
	private Button appetizerButton;

	@FXML
	private Button seafoodButton;

	@FXML
	private Button pizzaButton;

	@FXML
	private Button noodlesButton;

	@FXML
	private Button hotdogButton;

	@FXML
	private Button beveragesButton;

	@FXML
	private Button kidButton;

	@FXML
	private Button sidesButton;

	@FXML
	private Button chickenButton;

	//appetizer
	@FXML
	private Button eggRollButton;

	@FXML
	private Button ceasarSaladButton;

	@FXML
	private Button garlicBreadButton;

	@FXML
	private Button fishCakeButton;

	//hot dog
	@FXML
	private Button texMexButton;

	@FXML
	private Button countyFareButton;

	@FXML
	private Button macButton;

	@FXML
	private Button dawgButton;

	//seafood
	@FXML
	private Button spicySquidButton;

	@FXML
	private Button grilledShrimpButton;

	@FXML
	private Button friedCalamariButton;

	@FXML
	private Button deepFriedCatfishButton;

	//chicken
	@FXML
	private Button grilledChickenButton;

	@FXML
	private Button lemonChickenButton;

	@FXML
	private Button orangeChickenButton;

	@FXML
	private Button sesameChickenButton;

	//noodles
	@FXML
	private Button pastaButton;

	@FXML
	private Button riceNoodleButton;

	@FXML
	private Button lomeinButton;

	@FXML
	private Button eggNoodleButton;

	//pizza
	@FXML
	private Button pepperoniButton;

	@FXML
	private Button cheeseButton;

	@FXML
	private Button allMeatButton;

	@FXML
	private Button veggieButton;

	//beef
	@FXML
	private Button ribEyeButton;

	@FXML
	private Button tBoneButton;

	@FXML
	private Button sirloinButton;

	@FXML
	private Button nyStripButton;

	//kid
	@FXML
	private Button friedChickenButton;

	@FXML
	private Button chickenNuggetsButton;

	@FXML
	private Button cheeseBurgerButton;

	@FXML
	private Button chickenFingerButton;

	//sides
	@FXML
	private Button cheesFriesButton;

	@FXML
	private Button macNCheseButton;

	@FXML
	private Button riceButton;

	@FXML
	private Button onionRingsButton;

	//beverages
	@FXML
	private Button sodaButton;

	@FXML
	private Button teaButton;

	@FXML
	private Button beerButton;

	@FXML
	private Button wineButton;
	//end of menu items



	@FXML
	private TextArea billTotal;

	@FXML
	private TextArea orderDetails;

	@FXML
	private ListView<String> list;

	@FXML
	private RadioButton dineInButton;

	@FXML
	private RadioButton togoButton;

	@FXML
	private Button homeButton;

	@FXML
	private Pane appetizerPane;

	@FXML
	private Pane hotdogPane;

	@FXML
	private Pane seafoodPane;

	@FXML
	private Pane chickenPane;

	@FXML
	private Pane noodlesPane;

	@FXML
	private Pane pizzaPane;

	@FXML
	private Pane beefPane;

	@FXML
	private Pane kidPane;

	@FXML
	private Pane sidesPane;

	@FXML
	private Pane beveragesPane;

	@FXML
	private ChoiceBox<String> tables;
}

