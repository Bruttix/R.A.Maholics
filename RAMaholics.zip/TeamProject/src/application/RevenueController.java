package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.Pane;
import java.io.PrintWriter;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class RevenueController{

	@FXML
	private DatePicker start;

	@FXML
	private DatePicker end;

	@FXML
	private Button submitButton;

	@FXML
	private Button homeButton;


	@FXML
	private LineChart<String, Double> lineChart;

	Alert alert = new Alert(Alert.AlertType.NONE);
	Model mod = new Model();



	@FXML
	void HandleSubmitButton(ActionEvent event) throws FileNotFoundException{
		lineChart.getData().clear();

		ArrayList<String> dates = new ArrayList<String>();
		ArrayList<Double> sales = new ArrayList<Double>();

		ordersHandler();
		XYChart.Series <String, Double> series = new XYChart.Series<String, Double>();
		series.setName("Sales by Dates");
		String startDate = start.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		String endDate = end.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		File fp = new File("revenue.txt");
		Scanner scan = new Scanner(fp);
		while (scan.hasNextLine()){
			String newLine = scan.nextLine();
			String values[] = newLine.split(" ");
			dates.add(values[0]);
			sales.add(Double.parseDouble(values[1]));
		}
		scan.close();

		if(startDate.compareTo(endDate) == 1){
			alert.setAlertType(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Error");
			alert.setContentText("End date cannot be less than start date");
			alert.show();
		}
		if(!dates.contains(startDate) || !dates.contains(endDate)){
			alert.setAlertType(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Error");
			alert.setContentText("Dates are not in range");
			alert.show();
		} else{
			int startIndex = dates.indexOf(startDate), endIndex = dates.indexOf(endDate);

			for(int i = startIndex; i <= endIndex; i++){
				series.getData().add(new XYChart.Data<String, Double>(dates.get(i), sales.get(i)));
				lineChart.getData().add(series);
			}
		}

		start.setValue(null);
		end.setValue(null);

	}//end handle submit

	@FXML
	void HandleHomeButton(ActionEvent event) throws IOException{
		mod.ClearEmployeeLoginSession();
		Pane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();

	}
	//TODO: haven't implemented the call to this function.. maybe new button? (End of Day Count button?)
	//orders.txt sum's to revenue.txt
	void ordersHandler() throws FileNotFoundException{
		double sum = 0;
		String orderDate = null;
		File fp = new File("order.txt");
		Scanner scan = new Scanner(fp);
		while (scan.hasNextLine()){
			String newLine = scan.nextLine();
			String values[] = newLine.split(" ");
			orderDate = values[3];
			sum += (Double.parseDouble(values[1]));
		}
		scan.close();
		//write new total pulled from order.txt to revenue.txt
		PrintWriter writer = null;
		try{
			File rev = new File("revenue.txt");
			FileWriter fw = new FileWriter(rev,true);
			String newLine = "\n" + orderDate + " " + Double.toString(sum);
			fw.write(newLine);
			fw.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}

		//after sending sum to revenue, clear contents for next order
		String fileName = "order.txt";
		PrintWriter writeNew = null;
		try{
			writeNew = new PrintWriter(fileName);
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		writeNew.close();
}
}
