package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class SelectionController implements Initializable{

	@FXML
	private ImageView femalePic;

	@FXML
	private ImageView malePic;

	ArrayList<Employee> employ = new ArrayList<Employee>();
	Model mod = new Model();

	@FXML
	void HandleSalaryButton(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Salary.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	@FXML
	void HandleRevenueButton(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Revenue.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	@FXML
	void handleSale(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Sales.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	@FXML
	void handleEmployee(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Employee.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	@FXML
	void HandleHomeButton(ActionEvent event) throws IOException{
		mod.ClearEmployeeLoginSession();
		Pane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		try {
			mod.ReadEmployeeFile(employ);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String gender="";
		File fp = new File("employeeloginsession.txt");
		try {
			Scanner scan = new Scanner(fp);
			String logins = scan.nextLine();
			String values[] = logins.split(" ");
			int ID = Integer.parseInt(values[0]);
			System.out.println(ID);

			for(int i = 0; i < employ.size(); i++){
				System.out.println(employ.get(i).GetGender());
				if(ID == employ.get(i).GetUserID()){
					gender = employ.get(i).GetGender();
					System.out.println(gender);
					break;
				}//end if
			}//end for loop

			if(gender.equalsIgnoreCase("Female")){
				femalePic.setVisible(true);
				malePic.setVisible(false);
			}else{
				femalePic.setVisible(false);
				malePic.setVisible(true);
			}

			scan.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
