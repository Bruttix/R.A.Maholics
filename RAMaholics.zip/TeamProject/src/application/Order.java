package application;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class Order {

	String date, orderType, employeeID;
	double amount;

	public Order (String date, String orderType, String employeeID, double amount){
		this.date = date;
		this.orderType = orderType;
		this.employeeID = employeeID;
		this.amount = amount;
	}

	public void SetAmount(double amount){
		 this.amount = amount;
	}

	public void SetDate(String date){
		this.date = date;
	}

	public void SetOrderType(String orderType){
		this.orderType = orderType;
	}

	public void SetEmployeeID(String employeeID){
		 this.employeeID = employeeID;
	}

	public String GetOrderType(){
		return this.orderType;
	}

	public String GetEmployeeID(){
		return this.employeeID;
	}

	public String GetDate(){
		return this.date;
	}

	public double GetAmount(){
		return this.amount;
	}
}
