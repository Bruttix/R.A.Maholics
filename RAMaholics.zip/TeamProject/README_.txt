1. R.A.M (Restaurant Activites Manager) 

2. (R.A.M~aholics)
 	
3.	-Dinh Tran
   	-Brandon Greene
  	-Phetty Samson
	-Victor Aguilar

4. A tool for restaurant operations such as order taking, table scheduling, salaries, revenue, and employee clocking (in/out) timestamps.

5. Known bugs include:
	1- Employee creation writer to employee.txt doesn't write the contents.
	2- If trying to collect Revenue collected you must be precise on dates entered that those were actual days logged in revenue.txt ; 
	3- Revenue home button returns to login screen.
6. Pass code : 0313
7. Java 1.8 compiler